# numero = 1
# while numero < 100:
#     print(numero)
#     numero *= 2


while True:
    comando = input("$ ")
    print(comando)
    if comando.lower() == "salir":
        break
