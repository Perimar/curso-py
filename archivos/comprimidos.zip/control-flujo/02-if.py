edad = 15
if edad > 54:
    print("Puedes ver la película con descuento")
elif edad > 17:
    print("Puedes ver la película")
else:
    print("No puedes entrar")
    print("Ve a otro lado")

print("Listo")
