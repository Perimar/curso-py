try:
    n1 = int(input("Ingresa primer número: "))
except:
    print("ocurrio un error :(")
