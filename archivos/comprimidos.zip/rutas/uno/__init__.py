def init(graphql, **_):
    print(f"soy paquete uno: {graphql}")
