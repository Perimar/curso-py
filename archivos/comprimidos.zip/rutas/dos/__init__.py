def init(db, api, **_):
    print(f"soy paquete dos: {db} {api}")
