nombre = "Pere"
apellido = "Sabatés"
nombre_completo = f"{nombre} {apellido}"
print(nombre_completo)
