nombre_curso = "Ultimate Python"
nombre1 = "Ultimate Python"
Nombre_Curso = "Hola"
print(nombre_curso, nombre1, Nombre_Curso)
alumnos = 5000
puntaje = 9.9
publicado = True
