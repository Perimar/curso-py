# ngjgpsñsñsñ
# \"
# \'
# \\
# \n

curso = "Ultimate \nPython\""
print(curso)
