numero = 2  # entero -> integer
decimal = 1.2  # float
imaginario = 2 + 2j  # 2 + 2i

# numero = numero + 2
numero += 2

print("numero", numero)
print(1 + 3)
print(1 - 3)
print(1 * 3)
print(1 / 3)
print(1 // 3)
print(8 % 3)
print(2 ** 3)
