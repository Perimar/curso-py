mascotas = ["Pelusa", "Wolfgang", "Felipe", "Wolfgang"]

print(mascotas.count("Wolfgang"))
if "Wolfgang" in mascotas:
    print(mascotas.index("Wolfgang"))
