def hola(nombre, apellido="Feliz"):
    print("Hola Mundo!")
    print(f"Benvingut {nombre} {apellido}")


hola("Pere", "Sabatés")
hola("Chanchito")


hola(apellido="Sabatés", nombre="Pere")
