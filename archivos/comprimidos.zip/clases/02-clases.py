class Perro:
    def habla(self):
        print("Guau!")


mi_perro = Perro()
mi_perro.habla()
print(isinstance(mi_perro, Perro))
