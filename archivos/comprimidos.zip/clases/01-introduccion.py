mensaje = "Hola mundo"
print(type(mensaje))

# Clase: es el plano de construcción
# Objeto: es una instancia de una clase

# Clase: por ejemplo: el plano de construcción de una casa
# Objeto: es la casa construída

# Clase: por ejemplo: Humano
# Objeto: Nicolás, Felipe, Pere, María...
